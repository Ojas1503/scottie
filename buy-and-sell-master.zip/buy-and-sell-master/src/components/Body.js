import styled from 'styled-components';

const Body = styled.div`
  margin-bottom: 50px;
`;

export default Body;
