export const colorG = '#009432';
export const colorB = '#227093';
export const colorR = '#EE5A24';
export const colorO = '#F79F1F';
export const colorA = '#006266';
export const colorBlack = '#1b1f23';
